
#include <filesystem>

int main()
{
    std::filesystem::path pp{ ".." };
    return 0;
}
