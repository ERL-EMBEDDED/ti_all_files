[![Build Status](https://github.com/GENIVI/CANdb/actions/workflows/cmake.yml/badge.svg)](https://github.com/GENIVI/CANdb/actions/workflows/cmake.yml)
# CANdb
Library for parsing CAN bus database description formats
